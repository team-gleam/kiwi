package com.gleam.kiwi.model

data class User(
    val username: String,
    val password: String
)